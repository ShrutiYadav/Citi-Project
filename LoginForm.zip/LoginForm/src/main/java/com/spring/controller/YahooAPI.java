package com.spring.controller;

@Data
@Entity
public class YahooAPI {

	private @Id @GeneratedValue Long id;
	private String Company_Name  ;
	private String BSE;
	private String NSE;
	private float Diff;
	private float Diffper;

	private YahooAPI() {}

	public YahooAPI(String Company_Name, String BSE, String NSE,float Diff,float Diffper) {
		this. Company_Name=  Company_Name;
		this.BSE = BSE;
		this.NSE = NSE;
		this.Diff=Diff;
		this.Diffper=Diffper;
		
}
}